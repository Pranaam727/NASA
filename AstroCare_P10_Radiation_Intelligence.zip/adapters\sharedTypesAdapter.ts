/**
 * ASTROCARE P10 - SHARED TYPES FALLBACK ADAPTER
 * 
 * If your destination project lacks @/types/telemetry or @/types/database.types,
 * you can point imports to this adapter file.
 */

export type DataSourceType = 'HARDWARE_STREAM' | 'SIMULATOR' | 'MANUAL_ENTRY' | 'LAB_IMPORT';

export type QualityStatus = 'NOMINAL' | 'DEGRADED_SIGNAL' | 'OUT_OF_BOUNDS' | 'SENSOR_DISCONNECTED';

export type AlertSeverity = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface RadiationPacket {
  packetId: string;
  astronautId: string;
  missionId: string;
  timestamp: string;
  dataSource: DataSourceType;
  isSimulated: boolean;
  ambientFluxUsVh: number;
  accumulatedDoseMSv: number;
  solarParticleEventActive: boolean;
  quality: QualityStatus;
}

export interface HealthAlert {
  id?: string;
  astronaut_id?: string;
  astronautId?: string;
  rule_id?: string;
  ruleId?: string;
  severity: AlertSeverity;
  subsystem?: string;
  message: string;
  trigger_value?: number;
  triggerValue?: number;
  unit?: string;
  status: 'ACTIVE' | 'ACKNOWLEDGED' | 'RESOLVED' | 'DISMISSED';
  timestamp?: string;
  created_at?: string;
}
