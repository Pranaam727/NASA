# SHARED MODIFICATIONS FOR P10 INTEGRATION

When merging Prompt 10 into an existing AstroCare codebase, apply the following shared file modifications:

---

## 1. Route Registration (`src/App.tsx`)

Add the `/radiation` route and lazy/direct import for `RadiationPage`:

```tsx
// 1. Import
import { RadiationPage } from '@/pages/RadiationPage';

// 2. In your Routes definition:
<Route path="/radiation" element={<RadiationPage />} />
```

---

## 2. Navigation Constants (`src/constants/routes.ts`)

Add the Radiation navigation item:

```ts
export const NAV_ITEMS = [
  // ... existing items
  {
    path: '/radiation',
    label: 'Radiation Intelligence',
    icon: 'Radioactive', // or 'ShieldAlert', 'Sun' from lucide-react
    description: 'Radiation Dosimetry, NASA RadLab Telemetry & OSDR Biology',
  },
];
```

---

## 3. Telemetry Type Definitions (`src/types/telemetry.ts`)

Ensure `RadiationPacket` is defined. If missing, append:

```ts
export interface RadiationPacket {
  packetId: string;
  astronautId: string;
  missionId: string;
  timestamp: string;
  dataSource: 'SIMULATOR' | 'HARDWARE_STREAM' | 'MANUAL_ENTRY' | 'LAB_IMPORT';
  isSimulated: boolean;
  ambientFluxUsVh: number;
  accumulatedDoseMSv: number;
  solarParticleEventActive: boolean;
  quality: 'NOMINAL' | 'DEGRADED_SIGNAL' | 'OUT_OF_BOUNDS' | 'SENSOR_DISCONNECTED';
}
```

---

## 4. Simulation Engine Registration (`src/features/simulation/engine/SimulationEngine.ts`)

Ensure `simulationEngine` emits `RadiationPacket` and exposes `onRadiationPacket` and `getLatestRadiation`:

```ts
// In SimulationEngine class:
public getLatestRadiation(): RadiationPacket | null {
  return this.latestRadiation;
}

public onRadiationPacket(callback: (packet: RadiationPacket) => void): () => void {
  this.radiationListeners.add(callback);
  return () => this.radiationListeners.delete(callback);
}
```
*(Note: If the destination project lacks this, simply point `useRadiationTelemetry.ts` to `adapters/simulationEngineAdapter.ts`)*.

---

## 5. Central Alert Service (`src/services/dataProvider.ts`)

Ensure `alertService.triggerAlert` accepts the radiation alert schema:

```ts
alertService.triggerAlert({
  astronautId: 'ASTRO-01',
  ruleId: 'RULE_RAD_SOLAR_EVENT_CRITICAL',
  severity: 'CRITICAL',
  subsystem: 'RADIATION',
  message: 'Solar Particle Event flux surge detected (3.52 uSv/h)',
  triggerValue: 3.52,
  unit: 'uSv/h',
});
```
*(Note: If missing, point `radiationAnalyticsService.ts` to `adapters/alertServiceAdapter.ts`)*.
