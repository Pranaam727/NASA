/**
 * ASTROCARE P10 - ALERT SERVICE STANDALONE ADAPTER
 * 
 * If your destination project lacks @/services/dataProvider or alertService,
 * this adapter provides an alert dispatch queue with listener support.
 */

import { HealthAlert } from './sharedTypesAdapter';

type AlertListener = (alert: HealthAlert) => void;

class StandaloneAlertServiceAdapter {
  private alerts: HealthAlert[] = [];
  private listeners: Set<AlertListener> = new Set();

  public triggerAlert(alertData: Partial<HealthAlert>): HealthAlert {
    const newAlert: HealthAlert = {
      id: alertData.id || `alert-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      astronaut_id: alertData.astronaut_id || alertData.astronautId || 'ASTRO-01',
      astronautId: alertData.astronaut_id || alertData.astronautId || 'ASTRO-01',
      rule_id: alertData.rule_id || alertData.ruleId || 'RULE_RAD_ELEVATED',
      ruleId: alertData.rule_id || alertData.ruleId || 'RULE_RAD_ELEVATED',
      severity: alertData.severity || 'MEDIUM',
      subsystem: alertData.subsystem || 'RADIATION',
      message: alertData.message || 'Radiation alert detected',
      trigger_value: alertData.trigger_value ?? alertData.triggerValue,
      triggerValue: alertData.trigger_value ?? alertData.triggerValue,
      unit: alertData.unit || 'uSv/h',
      status: 'ACTIVE',
      timestamp: alertData.timestamp || new Date().toISOString(),
      created_at: alertData.created_at || new Date().toISOString(),
    };

    this.alerts.unshift(newAlert);
    if (this.alerts.length > 50) this.alerts.pop();

    this.listeners.forEach((listener) => {
      try {
        listener(newAlert);
      } catch (err) {
        console.error('[AlertServiceAdapter] Listener error:', err);
      }
    });

    return newAlert;
  }

  public getActiveAlerts(): HealthAlert[] {
    return this.alerts.filter((a) => a.status === 'ACTIVE');
  }

  public onAlert(listener: AlertListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }
}

export const standaloneAlertService = new StandaloneAlertServiceAdapter();
