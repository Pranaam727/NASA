/**
 * ASTROCARE P10 - SHARED UI COMPONENTS FALLBACK ADAPTER
 * 
 * If your target project does not have the P01-P03 Swiss Editorial layout components,
 * you can use these lightweight styled replacements.
 */

import React from 'react';

export const PageContainer: React.FC<{
  children: React.ReactNode;
  className?: string;
  maxWidth?: 'standard' | 'wide' | 'full';
}> = ({ children, className = '', maxWidth = 'standard' }) => {
  const maxMap = {
    standard: 'max-w-7xl',
    wide: 'max-w-[1600px]',
    full: 'max-w-full',
  };
  return (
    <div className={`w-full mx-auto p-4 md:p-6 lg:p-8 space-y-6 ${maxMap[maxWidth]} ${className}`}>
      {children}
    </div>
  );
};

export const PageHeader: React.FC<{
  title: string;
  subtitle?: string;
  badge?: React.ReactNode;
  actions?: React.ReactNode;
  metadata?: Array<{ label: string; value: string | number }>;
  className?: string;
}> = ({ title, subtitle, badge, actions, metadata, className = '' }) => {
  return (
    <header className={`border-b border-[#D8D2C6]/50 dark:border-[#383734] pb-4 mb-6 ${className}`}>
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold tracking-tight text-[#161514] dark:text-[#EDE8DF]">
              {title}
            </h1>
            {badge}
          </div>
          {subtitle && (
            <p className="text-xs text-[#706E6B] dark:text-[#9A9895] mt-1 font-mono uppercase tracking-wider">
              {subtitle}
            </p>
          )}
        </div>
        {actions && <div className="flex items-center gap-2">{actions}</div>}
      </div>
      {metadata && metadata.length > 0 && (
        <div className="flex flex-wrap gap-4 mt-3 pt-3 border-t border-[#D8D2C6]/30 dark:border-[#383734]/30 text-xs font-mono text-[#706E6B] dark:text-[#9A9895]">
          {metadata.map((item, idx) => (
            <div key={idx} className="flex items-center gap-1.5">
              <span className="text-[#9A9895] dark:text-[#706E6B]">{item.label}:</span>
              <span className="font-semibold text-[#161514] dark:text-[#EDE8DF]">{item.value}</span>
            </div>
          ))}
        </div>
      )}
    </header>
  );
};

export const StatusIndicator: React.FC<{
  status: 'NOMINAL' | 'CAUTION' | 'CRITICAL' | 'SIMULATED' | 'INFO';
  label?: string;
  size?: 'sm' | 'md';
  pulse?: boolean;
}> = ({ status, label, size = 'md', pulse = false }) => {
  const colorMap = {
    NOMINAL: { dot: 'bg-emerald-500', text: 'text-emerald-700 dark:text-emerald-400', bg: 'bg-emerald-500/10' },
    CAUTION: { dot: 'bg-amber-500', text: 'text-amber-700 dark:text-amber-400', bg: 'bg-amber-500/10' },
    CRITICAL: { dot: 'bg-rose-500', text: 'text-rose-700 dark:text-rose-400', bg: 'bg-rose-500/10' },
    SIMULATED: { dot: 'bg-orange-400', text: 'text-orange-700 dark:text-orange-400', bg: 'bg-orange-500/10' },
    INFO: { dot: 'bg-blue-500', text: 'text-blue-700 dark:text-blue-400', bg: 'bg-blue-500/10' },
  };
  const c = colorMap[status] || colorMap.INFO;

  return (
    <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded font-mono text-xs border border-current/20 ${c.bg} ${c.text}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${c.dot} ${pulse ? 'animate-ping' : ''}`} />
      {label || status}
    </span>
  );
};

export const DossierCard: React.FC<{
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}> = ({ title, subtitle, actions, children, className = '' }) => {
  return (
    <div className={`bg-white dark:bg-[#1E1D1B] border border-[#D8D2C6] dark:border-[#383734] rounded-sm p-4 ${className}`}>
      <div className="flex items-center justify-between pb-3 border-b border-[#D8D2C6]/40 dark:border-[#383734]/40 mb-4">
        <div>
          <h3 className="text-sm font-semibold tracking-wide text-[#161514] dark:text-[#EDE8DF]">
            {title}
          </h3>
          {subtitle && (
            <p className="text-[11px] text-[#706E6B] dark:text-[#9A9895] font-mono mt-0.5">
              {subtitle}
            </p>
          )}
        </div>
        {actions}
      </div>
      <div>{children}</div>
    </div>
  );
};

export const ChartContainer: React.FC<{
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
  children: React.ReactNode;
  height?: number;
  className?: string;
}> = ({ title, subtitle, actions, children, height = 300, className = '' }) => {
  return (
    <DossierCard title={title} subtitle={subtitle} actions={actions} className={className}>
      <div style={{ width: '100%', height }}>{children}</div>
    </DossierCard>
  );
};

export const MetricDisplay: React.FC<{
  label: string;
  value: string | number;
  unit?: string;
  subValue?: string;
  status?: 'NOMINAL' | 'CAUTION' | 'CRITICAL' | 'SIMULATED';
  icon?: React.ReactNode;
}> = ({ label, value, unit, subValue, icon }) => {
  return (
    <div className="bg-white dark:bg-[#1E1D1B] border border-[#D8D2C6] dark:border-[#383734] rounded-sm p-3.5">
      <div className="flex items-center justify-between text-xs text-[#706E6B] dark:text-[#9A9895] font-mono mb-1">
        <span>{label}</span>
        {icon}
      </div>
      <div className="flex items-baseline gap-1.5">
        <span className="text-2xl font-bold font-mono tracking-tight text-[#161514] dark:text-[#EDE8DF]">
          {value}
        </span>
        {unit && <span className="text-xs font-mono text-[#706E6B] dark:text-[#9A9895]">{unit}</span>}
      </div>
      {subValue && <div className="text-[11px] font-mono text-[#706E6B] dark:text-[#9A9895] mt-1">{subValue}</div>}
    </div>
  );
};

export const PrimaryButton: React.FC<{
  children: React.ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  className?: string;
}> = ({ children, onClick, disabled, className = '' }) => {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`px-3 py-1.5 text-xs font-mono font-medium rounded-sm bg-[#2D4A3E] text-white hover:bg-[#233A31] disabled:opacity-50 transition-colors ${className}`}
    >
      {children}
    </button>
  );
};
