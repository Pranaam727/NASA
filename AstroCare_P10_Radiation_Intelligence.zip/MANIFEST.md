# ASTROCARE P10 INTEGRATION PACKAGE MANIFEST

**Package Name:** `AstroCare_P10_Radiation_Intelligence.zip`  
**Generated:** 2026-11-14  
**Module:** Space Radiation Health Intelligence, NASA RadLab & OSDR Integration  
**Dependencies:** Recharts ($\ge 2.12$), Lucide-React ($\ge 0.344$), Zod ($\ge 3.22$)

---

## File Inventory

| Category | File in Archive | Original Project Path | Description |
| :--- | :--- | :--- | :--- |
| **Documentation** | `INTEGRATION_GUIDE.md` | `project-documentation/` | Complete installation, routing & API integration guide |
| **Documentation** | `SHARED_MODIFICATIONS.md` | `project-documentation/` | Exact code diffs for `App.tsx`, `routes.ts`, and contracts |
| **Documentation** | `MANIFEST.md` | `project-documentation/` | This manifest inventory |
| **Documentation** | `MANIFEST.json` | `project-documentation/` | Machine-readable manifest specification |
| **Verification** | `docs/radiation_page.png` | `radiation_page.png` | Visual QA verification screenshot of running UI |
| **P10 Core Types** | `src/features/radiation/types/radiationTypes.ts` | `src/features/radiation/types/radiationTypes.ts` | Core domain interfaces, thresholds & contracts |
| **P10 Core Math** | `src/features/radiation/utils/radiationUnits.ts` | `src/features/radiation/utils/radiationUnits.ts` | Unit converters, Quality Factor $Q$, trapezoidal integration |
| **P10 Data Fixture** | `src/features/radiation/data/radLabFixtures.ts` | `src/features/radiation/data/radLabFixtures.ts` | Authentic ISS Columbus DosTel2 flight telemetry |
| **P10 Data Fixture** | `src/features/radiation/data/osdrFixtures.ts` | `src/features/radiation/data/osdrFixtures.ts` | Authentic NASA OSDR studies & HRP risk briefs |
| **P10 Service** | `src/features/radiation/services/nasaRadLabService.ts` | `src/features/radiation/services/nasaRadLabService.ts` | Live NASA RadLab API client & Pandas split-table parser |
| **P10 Service** | `src/features/radiation/services/nasaOsdrService.ts` | `src/features/radiation/services/nasaOsdrService.ts` | NASA OSDR space biology study search & metadata fetcher |
| **P10 Service** | `src/features/radiation/services/nasaHrpService.ts` | `src/features/radiation/services/nasaHrpService.ts` | NASA Human Research Program evidence lookup |
| **P10 Service** | `src/features/radiation/services/radiationAnalyticsService.ts` | `src/features/radiation/services/radiationAnalyticsService.ts` | Trapezoidal numerical integration & alert evaluator |
| **P10 Service** | `src/features/radiation/services/radiationAiAdapter.ts` | `src/features/radiation/services/radiationAiAdapter.ts` | AI structured context adapter for Prompt 13 Gemini |
| **P10 Hook** | `src/features/radiation/hooks/useRadiationTelemetry.ts` | `src/features/radiation/hooks/useRadiationTelemetry.ts` | Real-time dosimeter telemetry stream hook |
| **P10 Hook** | `src/features/radiation/hooks/useNasaRadiationResearch.ts` | `src/features/radiation/hooks/useNasaRadiationResearch.ts` | NASA research query, filter, search & modal hook |
| **P10 Component** | `src/features/radiation/components/RadiationMetricCards.tsx` | `src/features/radiation/components/RadiationMetricCards.tsx` | Flux, dose, peak rate & RadLab reading cards |
| **P10 Component** | `src/features/radiation/components/RadiationExposureChart.tsx` | `src/features/radiation/components/RadiationExposureChart.tsx` | Dual-mode Recharts waveform with threshold lines |
| **P10 Component** | `src/features/radiation/components/RadiationAlertPanel.tsx` | `src/features/radiation/components/RadiationAlertPanel.tsx` | Threat banner, active alert triage, threshold log |
| **P10 Component** | `src/features/radiation/components/MissionExposurePanel.tsx` | `src/features/radiation/components/MissionExposurePanel.tsx` | ARES-VI 900-day mission & 500 mSv career limit gauge |
| **P10 Component** | `src/features/radiation/components/NasaRadLabExplorer.tsx` | `src/features/radiation/components/NasaRadLabExplorer.tsx` | Interactive instrument/spacecraft filter & table |
| **P10 Component** | `src/features/radiation/components/NasaOsdrResearchExplorer.tsx` | `src/features/radiation/components/NasaOsdrResearchExplorer.tsx` | Searchable study cards & metadata detail modal |
| **P10 Component** | `src/features/radiation/components/NasaHrpEvidencePanel.tsx` | `src/features/radiation/components/NasaHrpEvidencePanel.tsx` | HRP cancer & tissue degeneration evidence briefs |
| **P10 Component** | `src/features/radiation/components/RadiationProvenancePanel.tsx` | `src/features/radiation/components/RadiationProvenancePanel.tsx` | 4-quadrant scientific attribution matrix & disclaimer |
| **P10 Page** | `src/pages/RadiationPage.tsx` | `src/pages/RadiationPage.tsx` | Complete Swiss Editorial Space Radiation page |
| **P10 Tests** | `src/tests/radiationEngine.test.ts` | `src/tests/radiationEngine.test.ts` | Comprehensive 48 unit, integration & provenance tests |
| **Fallback Adapter** | `adapters/simulationEngineAdapter.ts` | `src/features/radiation/adapters/` | Standalone 1 Hz simulation stream generator fallback |
| **Fallback Adapter** | `adapters/alertServiceAdapter.ts` | `src/features/radiation/adapters/` | Standalone alert triage queue fallback |
| **Fallback Adapter** | `adapters/sharedComponentsAdapter.tsx` | `src/features/radiation/adapters/` | Standalone Swiss Editorial UI components fallback |
| **Fallback Adapter** | `adapters/sharedTypesAdapter.ts` | `src/features/radiation/adapters/` | Standalone telemetry & alert data contracts fallback |
