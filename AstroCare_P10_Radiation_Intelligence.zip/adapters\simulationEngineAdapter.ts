/**
 * ASTROCARE P10 - SIMULATION ENGINE STANDALONE ADAPTER
 * 
 * If your target AstroCare project does not yet have @/features/simulation/engine/SimulationEngine,
 * or has a different signature, this adapter provides an equivalent 1 Hz broadcast stream
 * and latest radiation packet getter.
 */

import { RadiationPacket } from './sharedTypesAdapter';

type RadiationPacketCallback = (packet: RadiationPacket) => void;

class StandaloneSimulationEngineAdapter {
  private listeners: Set<RadiationPacketCallback> = new Set();
  private timer: any = null;
  private currentFlux: number = 0.052;
  private totalDose: number = 48.64;
  private isSpe: boolean = false;
  private lastPacket: RadiationPacket;

  constructor() {
    this.lastPacket = this.generatePacket();
    this.start();
  }

  public getLatestRadiation(): RadiationPacket {
    return this.lastPacket;
  }

  public onRadiationPacket(callback: RadiationPacketCallback): () => void {
    this.listeners.add(callback);
    return () => this.listeners.delete(callback);
  }

  public triggerSolarFlare(active: boolean = true) {
    this.isSpe = active;
  }

  private generatePacket(): RadiationPacket {
    // Background noise + solar particle event surge
    const noise = (Math.random() - 0.5) * 0.005;
    const flux = this.isSpe 
      ? Math.max(1.8, 3.5 + (Math.random() - 0.5) * 0.8) 
      : Math.max(0.02, this.currentFlux + noise);
    
    // Accrue dose (flux is uSv/h -> convert to mSv/sec)
    this.totalDose += (flux / 3600000);

    return {
      packetId: `rad-pkt-${Date.now()}`,
      astronautId: 'ASTRO-01',
      missionId: 'ARES-VI',
      timestamp: new Date().toISOString(),
      dataSource: 'SIMULATOR',
      isSimulated: true,
      ambientFluxUsVh: Number(flux.toFixed(4)),
      accumulatedDoseMSv: Number(this.totalDose.toFixed(5)),
      solarParticleEventActive: this.isSpe,
      quality: 'NOMINAL',
    };
  }

  private start() {
    if (this.timer) return;
    this.timer = setInterval(() => {
      this.lastPacket = this.generatePacket();
      this.listeners.forEach((cb) => {
        try {
          cb(this.lastPacket);
        } catch (e) {
          console.error('[RadiationSimulationAdapter] Callback error:', e);
        }
      });
    }, 1000);
  }

  public stop() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }
}

export const standaloneSimulationEngine = new StandaloneSimulationEngineAdapter();
