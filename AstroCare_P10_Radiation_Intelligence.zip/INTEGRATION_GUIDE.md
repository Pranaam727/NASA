# ASTROCARE P10 INTEGRATION GUIDE
**Space Radiation Health Intelligence, NASA RadLab & OSDR Integration Package**

---

## 1. Overview
This integration package contains the complete, self-contained implementation of **Prompt 10 (Space Radiation Health Intelligence)** for AstroCare. It can be merged directly into any standard AstroCare project (post-P03 or later).

---

## 2. File Placement Map

Extract the contents of this archive into your target AstroCare project matching the following directory structure:

| Package File / Directory | Target Project Path | Purpose |
| :--- | :--- | :--- |
| `src/features/radiation/` | `src/features/radiation/` | Core module (types, units, services, hooks, fixtures, components) |
| `src/pages/RadiationPage.tsx` | `src/pages/RadiationPage.tsx` | Main page view mounted at `/radiation` |
| `src/tests/radiationEngine.test.ts` | `src/tests/radiationEngine.test.ts` | Complete 48-test verification suite |
| `adapters/` *(optional)* | `src/features/radiation/adapters/` | Standalone fallbacks if target project lacks P01-P09 services |
| `SHARED_MODIFICATIONS.md` | `project-documentation/` | Guide for modifying `App.tsx`, `routes.ts`, and contracts |

---

## 3. Required NPM Dependencies & Environment Variables

### 3.1 Dependencies
Ensure the following packages are installed in `package.json`:

```bash
npm install recharts lucide-react zod
```

- **`recharts`** ($\ge 2.12$): Dual-mode linear and cumulative dose waveforms with custom SVG reference lines and tooltips.
- **`lucide-react`** ($\ge 0.344$): Aerospace icons (`Radioactive`, `ShieldAlert`, `Sun`, `Database`, `BookOpen`, `ExternalLink`, etc.).
- **`zod`** ($\ge 3.22$): Telemetry and RadLab payload schema invariant validation.

### 3.2 Environment Variables
The module operates out of the box using public NASA APIs without mandatory API keys:
- **NASA RadLab API:** `https://visualization.osdr.nasa.gov/radlab/api/` (publicly accessible, no key needed).
- **NASA OSDR Search API:** `https://osdr.nasa.gov/osdr/data/search` (publicly accessible).
- **NASA OSDR Study Metadata:** `https://osdr.nasa.gov/osdr/data/osd/meta/` (publicly accessible).

*(Optional)* If using high-rate NASA API gateway proxies:
```env
# .env (optional)
VITE_NASA_API_KEY=DEMO_KEY
```

---

## 4. Public Module Exports & Interfaces

Import the primary module features from `src/features/radiation`:

```ts
// 1. Hooks
export { useRadiationTelemetry } from '@/features/radiation/hooks/useRadiationTelemetry';
export { useNasaRadiationResearch } from '@/features/radiation/hooks/useNasaRadiationResearch';

// 2. Services
export { nasaRadLabService } from '@/features/radiation/services/nasaRadLabService';
export { nasaOsdrService } from '@/features/radiation/services/nasaOsdrService';
export { nasaHrpService } from '@/features/radiation/services/nasaHrpService';
export { radiationAnalyticsService } from '@/features/radiation/services/radiationAnalyticsService';
export { exportRadiationContextForAI } from '@/features/radiation/services/radiationAiAdapter';

// 3. UI Components
export { RadiationPage } from '@/pages/RadiationPage';
export { RadiationMetricCards } from '@/features/radiation/components/RadiationMetricCards';
export { RadiationExposureChart } from '@/features/radiation/components/RadiationExposureChart';
export { RadiationAlertPanel } from '@/features/radiation/components/RadiationAlertPanel';
export { MissionExposurePanel } from '@/features/radiation/components/MissionExposurePanel';
export { NasaRadLabExplorer } from '@/features/radiation/components/NasaRadLabExplorer';
export { NasaOsdrResearchExplorer } from '@/features/radiation/components/NasaOsdrResearchExplorer';
export { NasaHrpEvidencePanel } from '@/features/radiation/components/NasaHrpEvidencePanel';
export { RadiationProvenancePanel } from '@/features/radiation/components/RadiationProvenancePanel';

// 4. Core Types & Constants
export {
  RadiationMeasurement,
  RadiationExposureRecord,
  RadiationResearchStudy,
  HrpEvidenceReference,
  RadiationAlert,
  DEMO_RADIATION_THRESHOLDS,
} from '@/features/radiation/types/radiationTypes';
```

---

## 5. NASA Integrations Guide

### 5.1 NASA RadLab Telemetry
The `nasaRadLabService` provides:
- Live parameterized REST queries to `https://visualization.osdr.nasa.gov/radlab/api/`.
- Automatic parser for Pandas `split` json tables (`{ columns: [...], data: [...] }`).
- Conversion of absorbed dose rate ($\mu\text{Gy/h}$) to equivalent dose rate ($\mu\text{Sv/h}$) using radiation biological quality factor $Q = 1.7$ when unprovided.
- Pre-seeded authentic historical flight archives from ISS Columbus module (DosTel2) in `src/features/radiation/data/radLabFixtures.ts`.
- Offline resilience: Falls back gracefully to authentic historical data if external network connectivity is restricted.

### 5.2 NASA Open Science Data Repository (OSDR)
The `nasaOsdrService` provides:
- Real-time full-text search against `https://osdr.nasa.gov/osdr/data/search`.
- Metadata retrieval from `/osd/meta/{OSD_STUDY_ID}`.
- Curated reference studies (`OSD-379`, `OSD-546`, `OSD-111`, `OSD-254`, `OSD-322`) covering heavy ion irradiation, DNA damage response, and spaceflight oxidative stress.
- Full modal view with direct accession links to official NASA OSDR repository records.

### 5.3 NASA Human Research Program (HRP)
The `nasaHrpService` provides:
- Direct evidence briefs on Radiation Carcinogenesis, Acute Radiation Syndromes, and Degenerative Tissue effects.
- Scientific citations and linkouts to the NASA Human Research Roadmap (`https://humanresearchroadmap.nasa.gov/evidence/`).

---

## 6. Route Registration

In your application router (e.g. `src/App.tsx`):

```tsx
import { RadiationPage } from '@/pages/RadiationPage';

// Inside your <Routes> switch:
<Route path="/radiation" element={<RadiationPage />} />
```

In your navigation menu (e.g. `src/constants/routes.ts` or layout sidebar):
```ts
{
  path: '/radiation',
  label: 'Radiation Intelligence',
  icon: Radioactive,
}
```

---

## 7. P01–P09 Shared Dependencies & Lightweight Adapters

The module is designed to integrate cleanly with standard AstroCare subsystems:

1. **Simulation Engine (`@/features/simulation/engine/SimulationEngine`):**
   - *Interface:* Exposes `getLatestRadiation()` and `onRadiationPacket(callback)`.
   - *Adapter:* If your project lacks this, import `standaloneSimulationEngine` from `adapters/simulationEngineAdapter.ts`.
2. **Alert Service (`@/services/dataProvider`):**
   - *Interface:* Exposes `alertService.triggerAlert(alert)`.
   - *Adapter:* If your project lacks this, import `standaloneAlertService` from `adapters/alertServiceAdapter.ts`.
3. **Swiss Editorial UI Components:**
   - *Components:* `PageContainer`, `PageHeader`, `DossierCard`, `ChartContainer`, `MetricDisplay`, `StatusIndicator`, `PrimaryButton`.
   - *Adapter:* If your project uses different layout primitives, drop in `adapters/sharedComponentsAdapter.tsx`.
4. **Data Contracts (`@/types/telemetry`, `@/types/database.types`):**
   - *Types:* `RadiationPacket`, `QualityStatus`, `DataSourceType`, `HealthAlert`, `AlertSeverity`.
   - *Adapter:* Self-contained in `adapters/sharedTypesAdapter.ts`.

---

## 8. Verification & Testing

Run the included test suite to verify correct installation:

```bash
npm test src/tests/radiationEngine.test.ts
```

All 48 tests will execute, validating:
1. Physical unit conversions ($\mu\text{Gy} \leftrightarrow \text{mGy} \leftrightarrow \text{Gy}$, $\mu\text{Sv} \leftrightarrow \text{mSv} \leftrightarrow \text{Sv}$, quality factor $Q$).
2. Numerical composite trapezoidal dose integration over continuous and gapped time series.
3. Trend analytics, peak detection, and solar particle event threshold evaluation.
4. Alert deduplication and 30-second cooldown windows.
5. NASA RadLab Pandas split parser and data normalization.
6. NASA OSDR study discovery and linkout generation.
7. NASA HRP risk evidence references.
8. AI context adapter serialization.
